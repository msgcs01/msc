
ASSIGNMENT 5

q1
// Step 1: Create Nodes

// Create Books
CREATE (:Book {title: "The Great Gatsby", tags: ["classic", "novel"], status: "in library", condition: "new", cost: 10.99, type: "Novel"});
CREATE (:Book {title: "Tinker, Tailor, Soldier, Spy", tags: ["classic", "drama"], status: "in library", condition: "old", cost: 9.99, type: "Novel"});
CREATE (:Book {title: "To Kill a Mockingbird", tags: ["classic", "novel"], status: "in library", condition: "new", cost: 12.99, type: "Novel"});

// Create Readers
CREATE (:Person {name: "Mr. Joshi", type: "Reader"});
CREATE (:Person {name: "Alan", type: "Reader"});
CREATE (:Person {name: "Lan", type: ["Reader", "Author"]});
CREATE (:Person {name: "Jane Doe", type: "Reviewer"});
CREATE (:Person {name: "Bob", type: "Reader"});

// Create Authors
CREATE (:Person {name: "John Le Carre", born: "1932-10-19", type: "Author", city: "Pune"});
CREATE (:Person {name: "Graham Greene", born: "1904-10-02", died: "1991-04-02", type: "Author", city: "Mumbai"});

// Create Publishers
CREATE (:Publisher {name: "Sc", city: "Pune"});
CREATE (:Publisher {name: "J.B.", city: "Mumbai"});




// Step 2: Create Relationships

// Publish Relationships
MATCH (b:Book {title: "The Great Gatsby"})
MATCH (p:Publisher {name: "Sc"})
CREATE (b)-[:PUBLISHED_BY]->(p);

MATCH (b:Book {title: "To Kill a Mockingbird"})
MATCH (p:Publisher {name: "J.B."})
CREATE (b)-[:PUBLISHED_BY]->(p);

// Issued Relationships
MATCH (r:Person {name: "Mr. Joshi"})
MATCH (b:Book {title: "The Great Gatsby"})
CREATE (r)-[:ISSUED_BY {date: "2024-09-10"}]->(b);

MATCH (r:Person {name: "Alan"})
MATCH (b:Book {title: "To Kill a Mockingbird"})
CREATE (r)-[:ISSUED_BY {date: "2024-09-11"}]->(b);

MATCH (r:Person {name: "Lan"})
MATCH (b:Book {title: "The Great Gatsby"})
CREATE (r)-[:ISSUED_BY {date: "2024-09-12"}]->(b);

// Step 3: Queries

// a) List all people who have issued a book "The Great Gatsby"
MATCH (r:Person)-[:ISSUED_BY]->(b:Book {title: "The Great Gatsby"})
RETURN r.name AS Issuer;


// b) Count the number of people who have read "To Kill a Mockingbird"
MATCH (r:Person)-[:ISSUED_BY]->(b:Book {title: "To Kill a Mockingbird"})
RETURN COUNT(r) AS NumberOfReaders;

// c) Add a property “Number of books issued” for Mr. Joshi and set its value as the count
MATCH (r:Person {name: "Mr. Joshi"})-[:ISSUED_BY]->(:Book)
WITH r, COUNT(*) AS issuedCount
SET r.numberOfBooksIssued = issuedCount
RETURN r.name AS Reader, r.numberOfBooksIssued AS NumberOfBooksIssued;


// d) List the names of publishers from Pune city
MATCH (p:Publisher {city: "Pune"})
RETURN p.name AS Publisher;

##############################################################################################################################################

q2

//2. Song Database

// Step 1: Create Nodes

// Create Songs
CREATE (:Song {title: "Song A", writer: "Author 1"});
CREATE (:Song {title: "Song B", writer: "Author 2"});
CREATE (:Song {title: "Song C", writer: "Author 1"});




// Create Artists
CREATE (:Artist {name: "Artist 1"});
CREATE (:Artist {name: "Artist 2"});
CREATE (:Artist {name: "Artist 3"});


// Create Record Companies
CREATE (:RecordCompany {name: "Company A"});
CREATE (:RecordCompany {name: "Company B"});


// Create Studios
CREATE (:Studio {name: "Studio A"});


// Step 2: Create Relationships

// Write Relationships
MATCH (a:Song {title: "Song A"})
MATCH (w:Artist {name: "Artist 1"})
CREATE (w)-[:WROTE]->(a);

MATCH (a:Song {title: "Song B"})
MATCH (w:Artist {name: "Artist 2"})
CREATE (w)-[:WROTE]->(a);

MATCH (a:Song {title: "Song C"})
MATCH (w:Artist {name: "Artist 1"})
CREATE (w)-[:WROTE]->(a);

// Finance Relationships
MATCH (s:Song {title: "Song A"})
MATCH (rc:RecordCompany {name: "Company A"})
CREATE (rc)-[:FINANCED]->(s);

// Perform Relationships
MATCH (s:Song {title: "Song A"})
MATCH (a:Artist {name: "Artist 1"})
CREATE (a)-[:PERFORMED]->(s);

// Record Relationships
MATCH (s:Song {title: "Song B"})
MATCH (st:Studio {name: "Studio A"})
CREATE (s)-[:RECORDED_AT]->(st);

// Step 3: Queries

// a) List the names of songs written by “Author 1”
MATCH (s:Song)
WHERE s.writer = "Author 1"
RETURN s.title AS Song;


// b) List the names of record companies who have financed for the song “Song A”
MATCH (rc:RecordCompany)-[:FINANCED]->(s:Song {title: "Song A"})
RETURN rc.name AS RecordCompany;


// c) List the names of artists performing the song “Song A”
MATCH (a:Artist)-[:PERFORMED]->(s:Song {title: "Song A"})
RETURN a.name AS Artist;


// d) Name the songs recorded by the studio “Studio A”
MATCH (s:Song)-[:RECORDED_AT]->(st:Studio {name: "Studio A"})
RETURN s.title AS Song;

##############################################################################################################################################

q3
3. Employee Database

// Step 1: Create Nodes

// Create Employees
CREATE (:Employee {name: "Alice", department: "HR", skills: ["Leadership", "Communication"]});
CREATE (:Employee {name: "Bob", department: "IT", skills: ["Java", "Networking"]});
CREATE (:Employee {name: "Charlie", department: "IT", skills: ["Python", "Databases"]});

// Create Departments
CREATE (:Department {name: "HR"});
CREATE (:Department {name: "IT"});
CREATE (:Department {name: "Finance"});

// Create Projects
CREATE (:Project {name: "Project X", budget: 100000});
CREATE (:Project {name: "Project Y", budget: 150000});

// Step 2: Create Relationships

// Work Relationships
MATCH (e:Employee {name: "Alice"})
MATCH (d:Department {name: "HR"})
CREATE (e)-[:WORKS_IN]->(d);

MATCH (e:Employee {name: "Bob"})
MATCH (d:Department {name: "IT"})
CREATE (e)-[:WORKS_IN]->(d);

MATCH (e:Employee {name: "Charlie"})
MATCH (d:Department {name: "IT"})
CREATE (e)-[:WORKS_IN]->(d);

// Control Relationships
MATCH (p:Project {name: "Project X"})
MATCH (d:Department {name: "IT"})
CREATE (d)-[:CONTROLS]->(p);

MATCH (p:Project {name: "Project Y"})
MATCH (d:Department {name: "Finance"})
CREATE (d)-[:CONTROLS]->(p);

// Step 3: Queries

// a) List the names of employees in the department “IT”
MATCH (e:Employee)-[:WORKS_IN]->(d:Department {name: "IT"})
RETURN e.name AS Employee;


// b) List the projects along with their properties, controlled by department “IT”
MATCH (d:Department {name: "IT"})-[:CONTROLS]->(p:Project)
RETURN p.name AS Project, p.budget AS Budget;

// c) List the departments along with the count of employees in it
MATCH (d:Department)<-[:WORKS_IN]-(e:Employee)
WITH d, COUNT(e) AS EmployeeCount
RETURN d.name AS Department, EmployeeCount;

// d) List the skillset for an employee “Alice”
MATCH (e:Employee {name: "Alice"})
RETURN e.skills AS Skillset;


##############################################################################################################################################
##############################################################################################################################################

q4


//4. Movie Database

// Step 1: Create Nodes
CREATE (:Movie {title: "Movie A", releaseYear: 2009});
CREATE (:Movie {title: "Movie B", releaseYear: 2015});
CREATE (:Movie {title: "Movie C", releaseYear: 2018});

// Create Actors
CREATE (:Actor {name: "Actor 1"});
CREATE (:Actor {name: "Actor 2"});
CREATE (:Actor {name: "Actor 3"});
CREATE (:Producer {name: "Producer 1"});
CREATE (:Producer {name: "Producer 2"});

// Create Reviewers
CREATE (:Reviewer {name: "Reviewer 1"});
CREATE (:Reviewer {name: "Reviewer 2"});

// Step 2: Create Relationships

// Act Relationships
MATCH (a:Actor {name: "Actor 1"})
MATCH (m:Movie {title: "Movie A"})
CREATE (a)-[:ACTED_IN]->(m);

MATCH (a:Actor {name: "Actor 2"})
MATCH (m:Movie {title: "Movie A"})
CREATE (a)-[:ACTED_IN]->(m);

MATCH (a:Actor {name: "Actor 2"})
MATCH (m:Movie {title: "Movie B"})
CREATE (a)-[:ACTED_IN]->(m);

MATCH (a:Actor {name: "Actor 3"})
MATCH (m:Movie {title: "Movie C"})
CREATE (a)-[:ACTED_IN]->(m);


// produce
MATCH (m:Movie {title: "Movie A"})
MATCH (p:Producer {name: "Producer 1"})
CREATE (m)-[:PRODUCED_BY]->(p);

MATCH (m:Movie {title: "Movie B"})
MATCH (p:Producer {name: "Producer 1"})
CREATE (m)-[:PRODUCED_BY]->(p);

MATCH (m:Movie {title: "Movie C"})
MATCH (p:Producer {name: "Producer 2"})
CREATE (m)-[:PRODUCED_BY]->(p);


// Review Relationships
MATCH (r:Reviewer {name: "Reviewer 1"})
MATCH (m:Movie {title: "Movie A"})
CREATE (r)-[:REVIEWS]->(m);

MATCH (r:Reviewer {name: "Reviewer 2"})
MATCH (m:Movie {title: "Movie A"})
CREATE (r)-[:REVIEWS]->(m);

MATCH (r:Reviewer {name: "Reviewer 1"})
MATCH (m:Movie {title: "Movie B"})
CREATE (r)-[:REVIEWS]->(m);

MATCH (r:Reviewer {name: "Reviewer 2"})
MATCH (m:Movie {title: "Movie B"})
CREATE (r)-[:REVIEWS]->(m);

// Following Relationships
MATCH (r1:Reviewer {name: "Reviewer 1"})
MATCH (r2:Reviewer {name: "Reviewer 2"})
CREATE (r1)-[:FOLLOWS]->(r2);

// Step 3: Queries

// a) Find all actors who have acted in a movie “Movie A”
MATCH (a:Actor)-[:ACTED_IN]->(m:Movie {title: "Movie A"})
RETURN a.name AS Actor;

// b) Find all reviewer pairs, one following the other and both reviewing the same movie
MATCH (r1:Reviewer)-[:FOLLOWS]->(r2:Reviewer)
MATCH (r1)-[:REVIEWS]->(m:Movie)<-[:REVIEWS]-(r2)
RETURN r1, r2, m;

// c) Find all actors that acted in a movie together after 2010
MATCH (a1:Actor)-[:ACTED_IN]->(m:Movie)
WHERE m.releaseYear > 2010
MATCH (a2:Actor)-[:ACTED_IN]->(m)
RETURN a1.name AS Actor1, a2.name AS Actor2, m.title AS Movie;

// d) Find all movies produced by “Producer 1”
MATCH (m:Movie)-[:PRODUCED_BY]->(p:Producer {name: "Producer 1"})
RETURN m.title AS Movie;


##############################################################################################################################################
q5


// 5. Social Network Database
// Step 1: Create Nodes

// Create People
CREATE (:Person {name: "John", birthYear: 1990});
CREATE (:Person {name: "Tom", birthYear: 1991});
CREATE (:Person {name: "Alice", birthYear: 1990});
CREATE (:Person {name: "Bob", birthYear: 1988});

// Create Groups
CREATE (:Group {name: "Group A"});
CREATE (:Group {name: "Group B"});

// Step 2: Create Relationships

// Friendship Relationships (with 'knownSince' property)
MATCH (p1:Person {name: "John"})
MATCH (p2:Person {name: "Tom"})
CREATE (p1)-[:FRIEND {knownSince: 2010}]->(p2);

MATCH (p1:Person {name: "John"})
MATCH (p2:Person {name: "Alice"})
CREATE (p1)-[:FRIEND {knownSince: 2012}]->(p2);

// Group Membership Relationships
MATCH (p:Person {name: "John"})
MATCH (g:Group {name: "Group A"})
CREATE (p)-[:MEMBER_OF]->(g);

// Messages Posted by John in 2015
CREATE (:Message {content: "John's first message in 2015", year: 2015});
CREATE (:Message {content: "John's second message in 2015", year: 2015});

MATCH (j:Person {name: "John"})
MATCH (m:Message {content: "John's first message in 2015"})
CREATE (j)-[:POSTED]->(m);

MATCH (j:Person {name: "John"})
MATCH (m:Message {content: "John's second message in 2015"})
CREATE (j)-[:POSTED]->(m);


// Step 3: Queries

// a) Find all friends of “John”, along with the year, since when John knows them
MATCH (j:Person {name: "John"})-[r:FRIEND]->(f:Person)
RETURN f.name AS Friend, r.knownSince AS Year;

// b) List out the affiliations of John
MATCH (j:Person {name: "John"})-[:MEMBER_OF]->(g:Group)
RETURN g.name AS Group;


// c) Find all friends of John, who are born in the same year as John
MATCH (j:Person {name: "John"})-[:FRIEND]->(f:Person)
WHERE f.birthYear = j.birthYear
RETURN f.name AS Friend;


// d) List out the messages posted by John in his timeline, during the year 2015
MATCH (j:Person {name: "John"})-[:POSTED]->(m:Message)
WHERE m.year = 2015
RETURN m.content AS Message;

