q1
// Step 1: Create Nodes

// Create Books
CREATE (:Book {title: "The Great Gatsby", tags: ["classic", "novel"], status: "in library", condition: "new", cost: 10.99, type: "Novel"});
CREATE (:Book {title: "Tinker, Tailor, Soldier, Spy", tags: ["classic", "drama"], status: "in library", condition: "old", cost: 9.99, type: "Novel"});
CREATE (:Book {title: "To Kill a Mockingbird", tags: ["classic", "novel"], status: "in library", condition: "new", cost: 12.99, type: "Novel"});

// Create Readers
CREATE (:Person {name: "Alan", type: "Reader"});
CREATE (:Person {name: "Lan", type: ["Reader", "Author"]});
CREATE (:Person {name: "Jane Doe", type: "Reviewer"});
CREATE (:Person {name: "Bob", type: "Reader"});

// Create Authors
CREATE (:Person {name: "John Le Carre", born: "1932-10-19", type: "Author"});
CREATE (:Person {name: "Graham Greene", born: "1904-10-02", died: "1991-04-02", type: "Author"});

// Create Publishers
CREATE (:Publisher {name: "Sc"});
CREATE (:Publisher {name: "J.B."});

// Step 2: Create Relationships

// Create Relationships for Publishing
MATCH (b1:Book {title: "The Great Gatsby"})
MATCH (p1:Publisher {name: "Sc"})
CREATE (b1)-[:PUBLISHED_BY]->(p1);

MATCH (b2:Book {title: "To Kill a Mockingbird"})
MATCH (p2:Publisher {name: "J.B."})
CREATE (b2)-[:PUBLISHED_BY]->(p2);

// Create Relationships for Recommendations
MATCH (r1:Person {name: "Alan"})
MATCH (b1:Book {title: "The Great Gatsby"})
CREATE (r1)-[:RECOMMENDED]->(b1);

MATCH (r2:Person {name: "Lan"})
MATCH (b2:Book {title: "To Kill a Mockingbird"})
CREATE (r2)-[:RECOMMENDED]->(b2);

// Create Relationships for Issuing
MATCH (r1:Person {name: "Alan"})
MATCH (b1:Book {title: "The Great Gatsby"})
CREATE (r1)-[:ISSUED_BY {date: "2024-09-10"}]->(b1);

MATCH (r2:Person {name: "Bob"})
MATCH (b2:Book {title: "To Kill a Mockingbird"})
CREATE (r2)-[:ISSUED_BY {date: "2024-09-11"}]->(b2);

MATCH (r3:Person {name: "Lan"})
MATCH (b3:Book {title: "The Great Gatsby"})
CREATE (r3)-[:ISSUED_BY {date: "2024-09-12"}]->(b3);

// Step 3: Queries

// a) List all readers who have recommended either book “The Great Gatsby”, “Tinker, Tailor, Soldier, Spy”, or “To Kill a Mockingbird”
MATCH (r:Person)-[:RECOMMENDED]->(b:Book)
WHERE b.title IN ["The Great Gatsby", "Tinker, Tailor, Soldier, Spy", "To Kill a Mockingbird"]
RETURN r.name AS Reader;

// b) List the readers who haven’t recommended any book
MATCH (r:Person {type: "Reader"})
WHERE NOT (r)-[:RECOMMENDED]->(:Book)
RETURN r.name AS Reader;

// c) List the authors who have written a book that has been read/issued by the maximum number of readers
MATCH (a:Person {type: "Author"})<-[:WRITTEN_BY]-(b:Book)<-[:ISSUED_BY]-(r:Person)
WITH a, COUNT(DISTINCT r) AS readersCount
ORDER BY readersCount DESC
LIMIT 1
RETURN a.name AS Author, readersCount;

// d) List the names of books recommended by “Alan” and read by at least one reader
MATCH (r:Person {name: "Alan"})-[:RECOMMENDED]->(b:Book)<-[:ISSUED_BY]-(otherReader:Person)
RETURN b.title AS Book;

// e) List the names of books recommended by “Lan” and read by the maximum number of readers
MATCH (r:Person {name: "Lan"})-[:RECOMMENDED]->(b:Book)<-[:ISSUED_BY]-(otherReader:Person)
WITH b, COUNT(otherReader) AS readersCount
ORDER BY readersCount DESC
LIMIT 1
RETURN b.title AS Book, readersCount;

// f) List the names of publishers who haven’t published any books written by authors from Pune and Mumbai
MATCH (p:Publisher)
WHERE NOT EXISTS {  
  MATCH (p)<-[:PUBLISHED_BY]-(b:Book)-[:WRITTEN_BY]->(a:Person {type: "Author"})
  WHERE a.city IN ["Pune", "Mumbai"]
}
RETURN p.name AS Publisher;

// g) List the names of voracious readers in our library (who have read more than 2 books)
MATCH (r:Person {type: "Reader"})-[:ISSUED_BY]->(b:Book)
WITH r, COUNT(b) AS booksRead
WHERE booksRead > 2
RETURN r.name AS VoraciousReader, booksRead;



------------------------------------------------------------------------------------------------------------------

q2

// Step 1: Create Nodes

// Create Artists
CREATE (:Artist {name: "Artist A"});
CREATE (:Artist {name: "Artist B"});
CREATE (:Artist {name: "Artist C"});
CREATE (:Artist {name: "Artist D"});

// Create Songs
CREATE (:Song {title: "Song 1", genre: "Pop"});
CREATE (:Song {title: "Song 2", genre: "Rock"});
CREATE (:Song {title: "Song 3", genre: "Jazz"});
CREATE (:Song {title: "Song 4", genre: "Pop"});
CREATE (:Song {title: "Song 5", genre: "Rock"});

// Create Studios
CREATE (:Studio {name: "Studio X"});
CREATE (:Studio {name: "Studio Y"});

// Step 2: Create Relationships

// Songwriters
MATCH (s:Song {title: "Song 1"})
MATCH (a:Artist {name: "Artist A"})
CREATE (s)-[:WRITTEN_BY]->(a);

MATCH (s:Song {title: "Song 2"})
MATCH (a:Artist {name: "Artist A"})
CREATE (s)-[:WRITTEN_BY]->(a);

MATCH (s:Song {title: "Song 3"})
MATCH (a:Artist {name: "Artist B"})
CREATE (s)-[:WRITTEN_BY]->(a);

MATCH (s:Song {title: "Song 4"})
MATCH (a:Artist {name: "Artist C"})
CREATE (s)-[:WRITTEN_BY]->(a);

MATCH (s:Song {title: "Song 5"})
MATCH (a:Artist {name: "Artist D"})
CREATE (s)-[:WRITTEN_BY]->(a);


// Songs sung by Artists
MATCH (s:Song {title: "Song 1"})
MATCH (a:Artist {name: "Artist A"})
CREATE (a)-[:SUNG]->(s);

MATCH (s:Song {title: "Song 2"})
MATCH (a:Artist {name: "Artist A"})
CREATE (a)-[:SUNG]->(s);

MATCH (s:Song {title: "Song 3"})
MATCH (a:Artist {name: "Artist B"})
CREATE (a)-[:SUNG]->(s);

MATCH (s:Song {title: "Song 4"})
MATCH (a:Artist {name: "Artist C"})
CREATE (a)-[:SUNG]->(s);

MATCH (s:Song {title: "Song 5"})
MATCH (a:Artist {name: "Artist D"})
CREATE (a)-[:SUNG]->(s);


// Songs recorded in studios
MATCH (s:Song {title: "Song 1"})
MATCH (st:Studio {name: "Studio X"})
CREATE (s)-[:RECORDED_IN]->(st);

MATCH (s:Song {title: "Song 2"})
MATCH (st:Studio {name: "Studio Y"})
CREATE (s)-[:RECORDED_IN]->(st);

MATCH (s:Song {title: "Song 3"})
MATCH (st:Studio {name: "Studio X"})
CREATE (s)-[:RECORDED_IN]->(st);

MATCH (s:Song {title: "Song 4"})
MATCH (st:Studio {name: "Studio Y"})
CREATE (s)-[:RECORDED_IN]->(st);

MATCH (s:Song {title: "Song 5"})
MATCH (st:Studio {name: "Studio X"})
CREATE (s)-[:RECORDED_IN]->(st);


// Financing
MATCH (s:Song {title: "Song 1"})
MATCH (st:Studio {name: "Studio X"})
CREATE (st)-[:FINANCED_BY {amount: 1000}]->(s);

MATCH (s:Song {title: "Song 3"})
MATCH (st:Studio {name: "Studio Y"})
CREATE (st)-[:FINANCED_BY {amount: 2000}]->(s);

// Step 3: Queries

// a) List the names of artists who have sung only songs written by a specific artist (replace "Artist A" with the desired artist's name)
MATCH (a:Artist)-[:SUNG]->(s:Song)
WITH a, COLLECT(s) AS songs
MATCH (s)-[:WRITTEN_BY]->(w:Artist)
WITH a, songs, COLLECT(w) AS writers
WHERE ALL(writer IN writers WHERE writer.name = "Artist A")
RETURN a.name AS Artist;

// b) List the names of artists who have sung the maximum number of songs recorded by a specific studio (replace "Studio X" with the desired studio's name)
MATCH (s:Song)-[:RECORDED_IN]->(st:Studio {name: "Studio X"})<-[:SUNG]-(a:Artist)
WITH a, COUNT(s) AS songCount
ORDER BY songCount DESC
LIMIT 1
RETURN a.name AS Artist, songCount;

// c) List the names of songs financed by a specific studio and sung by a specific artist (replace "Studio Y" and "Artist B" with desired values)
MATCH (s:Song)-[:FINANCED_BY]->(st:Studio {name: "Studio Y"})<-[:SUNG]-(a:Artist {name: "Artist B"})
RETURN s.title AS Song;

*********************************************************
------------------------------------------------------------------------------------------------------------------

q3

// Step 1: Create Nodes

// Create Employees
CREATE (:Employee {name: "Alice", skills: ["Java", "SQL", "Project Management"], department: "IT"});
CREATE (:Employee {name: "Bob", skills: ["Java", "C++", "Database Administration"], department: "IT"});
CREATE (:Employee {name: "Charlie", skills: ["Python", "Java", "SQL"], department: "HR"});
CREATE (:Employee {name: "David", skills: ["C++", "Java", "Networking"], department: "IT"});
CREATE (:Employee {name: "Eve", skills: ["Python", "Machine Learning"], department: "Data Science"});

// Create Departments
CREATE (:Department {name: "IT"});
CREATE (:Department {name: "HR"});
CREATE (:Department {name: "Data Science"});

// Create Projects
CREATE (:Project {name: "Project A", description: "IT Infrastructure Improvement"});
CREATE (:Project {name: "Project B", description: "HR Management System"});
CREATE (:Project {name: "Project C", description: "Data Analysis Project"});


// Step 2: Create Relationships

// Employee-Department Relationships
MATCH (e1:Employee {name: "Alice"})
MATCH (d1:Department {name: "IT"})
CREATE (e1)-[:WORKS_IN]->(d1);

MATCH (e2:Employee {name: "Bob"})
MATCH (d2:Department {name: "IT"})
CREATE (e2)-[:WORKS_IN]->(d2);

MATCH (e3:Employee {name: "Charlie"})
MATCH (d3:Department {name: "HR"})
CREATE (e3)-[:WORKS_IN]->(d3);

MATCH (e4:Employee {name: "David"})
MATCH (d1:Department {name: "IT"})
CREATE (e4)-[:WORKS_IN]->(d1);

MATCH (e5:Employee {name: "Eve"})
MATCH (d4:Department {name: "Data Science"})
CREATE (e5)-[:WORKS_IN]->(d4);


// Project-Controlled Relationships
MATCH (p1:Project {name: "Project A"})
MATCH (d1:Department {name: "IT"})
CREATE (p1)-[:CONTROLLED_BY]->(d1);

MATCH (p2:Project {name: "Project B"})
MATCH (d3:Department {name: "HR"})
CREATE (p2)-[:CONTROLLED_BY]->(d3);

MATCH (p3:Project {name: "Project C"})
MATCH (d4:Department {name: "Data Science"})
CREATE (p3)-[:CONTROLLED_BY]->(d4);

// Step 3: Queries

// a) List the names of employees having the same skills as employee “Alice”
MATCH (e:Employee {name: "Alice"})
WITH e.skills AS aliceSkills
MATCH (otherEmployee:Employee)
WHERE otherEmployee.name <> "Alice" AND ALL(skill IN aliceSkills WHERE skill IN otherEmployee.skills)
RETURN otherEmployee.name AS EmployeeWithSameSkills;

// b) List the projects controlled by a department “IT” and have employees of the same department working in it
MATCH (d:Department {name: "IT"})<-[:CONTROLLED_BY]-(p:Project)
MATCH (e:Employee)-[:WORKS_IN]->(d)
RETURN p.name AS ProjectName;

// c) List the names of the projects belonging to departments managed by employee “Alice”
MATCH (e:Employee {name: "Alice"})-[:WORKS_IN]->(d:Department)
MATCH (p:Project)-[:CONTROLLED_BY]->(d)
RETURN p.name AS ProjectName;

------------------------------------------------------------------------------------------------------------------

q4

// Step 1: Create Nodes

// Create Movies
CREATE (:Movie {title: "Inception", year: 2010});
CREATE (:Movie {title: "The Dark Knight", year: 2008});
CREATE (:Movie {title: "Interstellar", year: 2014});
CREATE (:Movie {title: "Dunkirk", year: 2017});

// Create Actors
CREATE (:Actor {name: "Leonardo DiCaprio"});
CREATE (:Actor {name: "Joseph Gordon-Levitt"});
CREATE (:Actor {name: "Tom Hardy"});
CREATE (:Actor {name: "Christian Bale"});
CREATE (:Actor {name: "Matthew McConaughey"});

// Create Reviewers
CREATE (:Reviewer {name: "Alice"});
CREATE (:Reviewer {name: "Bob"});
CREATE (:Reviewer {name: "Charlie"});
CREATE (:Reviewer {name: "David"});

// Step 2: Create Relationships

// Actor-Movie Relationships with Roles
MATCH (a1:Actor {name: "Leonardo DiCaprio"})
MATCH (m1:Movie {title: "Inception"})
CREATE (a1)-[:ACTED_IN {role: "Dom Cobb"}]->(m1);

MATCH (a2:Actor {name: "Joseph Gordon-Levitt"})
MATCH (m1:Movie {title: "Inception"})
CREATE (a2)-[:ACTED_IN {role: "Arthur"}]->(m1);

MATCH (a3:Actor {name: "Tom Hardy"})
MATCH (m1:Movie {title: "Inception"})
CREATE (a3)-[:ACTED_IN {role: "Eames"}]->(m1);

MATCH (a4:Actor {name: "Christian Bale"})
MATCH (m2:Movie {title: "The Dark Knight"})
CREATE (a4)-[:ACTED_IN {role: "Bruce Wayne"}]->(m2);

MATCH (a5:Actor {name: "Tom Hardy"})
MATCH (m2:Movie {title: "The Dark Knight"})
CREATE (a5)-[:ACTED_IN {role: "Bane"}]->(m2);

MATCH (a1:Actor {name: "Matthew McConaughey"})
MATCH (m3:Movie {title: "Interstellar"})
CREATE (a1)-[:ACTED_IN {role: "Cooper"}]->(m3);

// Reviewer-Reviewer Relationships (Following)
MATCH (r1:Reviewer {name: "Alice"})
MATCH (r2:Reviewer {name: "Bob"})
CREATE (r1)-[:FOLLOWS]->(r2);

MATCH (r2:Reviewer {name: "Bob"})
MATCH (r3:Reviewer {name: "Charlie"})
CREATE (r2)-[:FOLLOWS]->(r3);

// Reviewer-Movie Relationships with Reviews
MATCH (r1:Reviewer {name: "Alice"})
MATCH (m1:Movie {title: "Inception"})
CREATE (r1)-[:REVIEWED {rating: 5, comment: "Amazing movie!"}]->(m1);

MATCH (r2:Reviewer {name: "Bob"})
MATCH (m1:Movie {title: "Inception"})
CREATE (r2)-[:REVIEWED {rating: 4, comment: "Great concept!"}]->(m1);

MATCH (r3:Reviewer {name: "Charlie"})
MATCH (m2:Movie {title: "The Dark Knight"})
CREATE (r3)-[:REVIEWED {rating: 5, comment: "Best Batman!"}]->(m2);

MATCH (r4:Reviewer {name: "David"})
MATCH (m3:Movie {title: "Interstellar"})
CREATE (r4)-[:REVIEWED {rating: 4, comment: "Thought-provoking."}]->(m3);

// Step 3: Queries

// a) List the names of actors that paired in multiple movies together
MATCH (a1:Actor)-[:ACTED_IN]->(m:Movie)<-[:ACTED_IN]-(a2:Actor)
WHERE a1 <> a2
WITH a1, a2, COUNT(m) AS movieCount
WHERE movieCount > 1
RETURN DISTINCT a1.name AS Actor1, a2.name AS Actor2;

// b) List all pairs of actors–movie subgraphs along with the roles played
MATCH (a1:Actor)-[r:ACTED_IN]->(m:Movie)<-[:ACTED_IN]-(a2:Actor)
RETURN a1.name AS Actor1, a2.name AS Actor2, m.title AS Movie, r.role AS Role;

// c) List all reviewers and the ones they are following directly or via another Reviewer
MATCH (r:Reviewer)
OPTIONAL MATCH (r)-[:FOLLOWS]->(f:Reviewer)
WITH r, COLLECT(f.name) AS follows
RETURN r.name AS Reviewer, follows;

// d) List the names of movies that have the most number of reviews
MATCH (m:Movie)<-[:REVIEWED]-(r:Reviewer)
WITH m, COUNT(r) AS reviewCount
ORDER BY reviewCount DESC
LIMIT 1
RETURN m.title AS Movie, reviewCount;


------------------------------------------------------------------------------------------------------------------

q5

// Step 1: Create Nodes

// Create People
CREATE (:Person {name: "John"});
CREATE (:Person {name: "Tom"});
CREATE (:Person {name: "Alice"});
CREATE (:Person {name: "Bob"});
CREATE (:Person {name: "Charlie"});
CREATE (:Person {name: "Diana"});
CREATE (:Person {name: "Eva"});

// Create Groups
CREATE (:Group {name: "Group A"});
CREATE (:Group {name: "Group B"});
CREATE (:Group {name: "Group C"});
CREATE (:Group {name: "Group D"});

// Step 2: Create Relationships

// Friend Relationships
MATCH (j:Person {name: "John"}), (t:Person {name: "Tom"})
CREATE (j)-[:FRIENDS_WITH]->(t);

MATCH (t:Person {name: "Tom"}), (a:Person {name: "Alice"})
CREATE (t)-[:FRIENDS_WITH]->(a);

MATCH (t:Person {name: "Tom"}), (b:Person {name: "Bob"})
CREATE (t)-[:FRIENDS_WITH]->(b);

MATCH (a:Person {name: "Alice"}), (c:Person {name: "Charlie"})
CREATE (a)-[:FRIENDS_WITH]->(c);

MATCH (b:Person {name: "Bob"}), (d:Person {name: "Diana"})
CREATE (b)-[:FRIENDS_WITH]->(d);

MATCH (c:Person {name: "Charlie"}), (e:Person {name: "Eva"})
CREATE (c)-[:FRIENDS_WITH]->(e);

// Group Membership Relationships
MATCH (j:Person {name: "John"}), (g1:Group {name: "Group A"})
CREATE (j)-[:MEMBER_OF]->(g1);

MATCH (t:Person {name: "Tom"}), (g1:Group {name: "Group A"})
CREATE (t)-[:MEMBER_OF]->(g1);

MATCH (t:Person {name: "Tom"}), (g2:Group {name: "Group B"})
CREATE (t)-[:MEMBER_OF]->(g2);

MATCH (a:Person {name: "Alice"}), (g2:Group {name: "Group B"})
CREATE (a)-[:MEMBER_OF]->(g2);

MATCH (a:Person {name: "Alice"}), (g3:Group {name: "Group C"})
CREATE (a)-[:MEMBER_OF]->(g3);

MATCH (b:Person {name: "Bob"}), (g3:Group {name: "Group C"})
CREATE (b)-[:MEMBER_OF]->(g3);

MATCH (c:Person {name: "Charlie"}), (g4:Group {name: "Group D"})
CREATE (c)-[:MEMBER_OF]->(g4);

// Timeline Messages
MATCH (j:Person {name: "John"})
CREATE (j)-[:POSTED {message: "Hello, World!", date: "2024-10-01"}]->(:TimelineMessage);

MATCH (j:Person {name: "John"})
CREATE (j)-[:POSTED {message: "Enjoying the day!", date: "2024-10-02"}]->(:TimelineMessage);

MATCH (j:Person {name: "John"})
CREATE (j)-[:POSTED {message: "Just finished a book!", date: "2024-10-03"}]->(:TimelineMessage);

MATCH (t:Person {name: "Tom"})
CREATE (t)-[:POSTED {message: "Excited for the weekend!", date: "2024-10-01"}]->(:TimelineMessage);

// Step 3: Queries

// a) List out the people who have created maximum timeline messages
MATCH (p:Person)-[:POSTED]->(:TimelineMessage)
WITH p, COUNT(*) AS messageCount
ORDER BY messageCount DESC
LIMIT 1
RETURN p.name AS Person, messageCount;

// b) List all friends of John’s friend, Tom
MATCH (j:Person {name: "John"})-[:FRIENDS_WITH]->(t:Person {name: "Tom"})-[:FRIENDS_WITH]->(friends)
RETURN friends.name AS FriendsOfTom;

// c) List the people with maximum friends
MATCH (p:Person)-[:FRIENDS_WITH]->(:Person) 
WITH p, COUNT(*) AS friendCount
ORDER BY friendCount DESC
LIMIT 1
RETURN p.name AS Person, friendCount;

// d) List the people who are part of more than 3 groups
MATCH (p:Person)-[:MEMBER_OF]->(:Group)
WITH p, COUNT(*) AS groupCount
WHERE groupCount > 3
RETURN p.name AS Person, groupCount;


------------------------------------------------------------------------------------------------------------------
