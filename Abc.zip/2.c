#############################################
ASSIGNMENT 2

db.Employee.insertOne(
  {
    "emp_Id": 9,
    "first_name": "Jonh",
    "last_name": "Doe",
    "email":"a@gmail.com",
    "address": {
      "house_No":12,
      "street": "123 Elm Street",
      "city": "Springfield",
      "state": "IL",
      "country": "USA",
      "pin_code": "62704"
    },
    "salary":25000,
    "designation":"Supervisor",
    "experiance":"2 yr",
    "date_of_joining":"2024-01-23",
    "birth_date":"2000-02-23"
  }
)

db.Transaction.insertMany([
  {
    "t_Id": 201,
    "t_date":"2024-01-23",
    "name": "Neha",
    "transaction_details": {
      "item_id":102,
      "item_name": "pen",
      "quantity": 10,
      "price": 100
    },
    "payment_details": {
      "p_type":"cash",
      "total_amt": "pen",
      "p_status": "successful",

    },
    "Remark":""
    
  }
])
#############################################

4.Update salary of all employee by giving an increment of rs 4000

> db.Employee.updateMany({}, { $inc: { salary: 4000 } });

{ "acknowledged" : true, "matchedCount" : 5, "modifiedCount" : 5 }
>
#############################################

5.Update the remark for transactioon 201

> db.Transaction.updateOne({ "t_Id": 201 }, { $set: { "Remark": "Good" } });
{ "acknowledged" : true, "matchedCount" : 1, "modifiedCount" : 1 }
> 
#############################################

6.Update designation of an emp name Jonh from supervisor to manager

> db.Employee.updateMany(
...   { "first_name": "Jonh", "designation": "Supervisor" },
...   { $set: { "designation": "Manager" } }
... );
{ "acknowledged" : true, "matchedCount" : 1, "modifiedCount" : 1 }
>
#############################################


7.Update  designation of an emp having emp_id 9
> db.Employee.updateMany(   { "emp_Id": 9, "designation": "Supervisor" },   
{ $set: { "designation": "Manager" } } );

{ "acknowledged" : true, "matchedCount" : 1, "modifiedCount" : 1 }
> db.Employee.find({ "emp_Id": 9 }).pretty();

#############################################

8.Change the addr of an emp having emp_id 9

> db.Employee.updateMany(   { "emp_Id": 9 },   
{ $set: { "address.city": "Pune" }} );

{ "acknowledged" : true, "matchedCount" : 1, "modifiedCount" : 1 }
> db.Employee.find({ "emp_Id": 9 }).pretty();

#############################################


9.Delete transaction made by "__" emp on the given date

> db.Transaction.deleteMany({ "name": "Shyam", "t_date": "2024-01-23" });
{ "acknowledged" : true, "deletedCount" : 1 }
#############################################

10.Delete all the employees whose first name starts with 'K'

> db.Employee.deleteMany({ "first_name": { $regex: "^K", $options: "i" } });
{ "acknowledged" : true, "deletedCount" : 4 }
> db.Employee.find({ "first_name": { $regex: "^K" } }).pretty();

> db.Employee.find().pretty();
