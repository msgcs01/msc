#############################################

ASSIGNMENT 3

db.Employee1.insertOne(
  {
    "emp_Id": 12,
    "name": "Kishor",
    "last_name": "Kumar",
    "email":"a@gmail.com",
    "address": {
      "house_No":12,
      "street": "123 Elm Street",
      "city": "Springfield",
      "state": "IL",
      "country": "USA",
      "pin_code": "62704"
    },
    "salary":25000,
    "designation":"floor supervisor",
    "experiance":"2 yr",
    "date_of_joining":"2024-01-23",
    "birth_date":"2000-02-23"
  }
)



db.Transaction1.insertOne(
  {
    "t_Id": 101,
    "t_date":"2024-01-23",
    "name": "Kishor",
    "transaction_details": {
      "item_id":102,
      "item_name": "pen",
      "quantity": 10,
      "price": 100
    },
    "payment_details": {
      "p_type":"cash",
      "total_amt": 100,
      "p_status": "successful",

    },
    "Remark":""
    
  }
)
 *************************************************************


1. Find employees having designation as either ‘manager’ or ‘floor supervisor’.

 db.Employee1.aggregate([
...     {
...         $match: {
...             designation: { $in: ['manager', 'floor supervisor'] }
...         }
...     }
... ]).pretty();

 *************************************************************

2. Find an employee whose name ends with "____Kumar or r_____" and print the
output in json format.

var results = db.Employee1.aggregate([
  {
    $match: {
      $or: [
        { "last_name": /Kumar$/ },
        { "last_name": /r.{4}$/ }
      ]
    }
  }
]).toArray();

printjson(results);
 *************************************************************

3. Display the name of an employee whose salary is greater than ___5000____ using a
MongoDB cursor.

var getsal = db.Employee1.find(
...   { salary: { $gt: 5000 } }, 
...   { _id: 0, name: 1, last_name: 1 }
... );

 while (getsal.hasNext()) {
...   printjson(getsal.next());
... }

 *************************************************************

4. Sort the employees in the descending order of their designation.

db.Employee1.aggregate([
...   {
...     $sort: { designation: -1 }
...   }
... ]).pretty();

 *************************************************************

5. Count the total number of employees in a collection.

db.Employee1.aggregate([
...   {
...     $count: "total_employees"
...   }
... ]).pretty();
 *************************************************************

6. Calculate the sum of the total amount paid for all the transaction documents.

db.Transaction1.aggregate([
  {
    $group: {
      _id: null,
      total_amount_paid: { $sum: { $toDouble: "$payment_details.total_amt" } }
    }
  }
]).pretty();

 *************************************************************

7. Calculate the sum of the total amount paid for each payment type.

db.Transaction1.aggregate([
  {
    $group: {
      _id: "$payment_details.p_type",
      total_amount_paid: { $sum: { $toDouble: "$payment_details.total_amt" } }
    }
  }
]).pretty();
 *************************************************************


8. Find the transaction id of the latest transaction.

db.Transaction1.aggregate([
...   {
...     $sort: { t_date: -1 }
...   },
...   {
...     $limit: 1
...   },
...   {
...     $project: { _id: 0, t_Id: 1 }
...   }
... ]).pretty();

 *************************************************************

9. Find designation of employees who have made transaction of amount
greater than Rs. 500.

db.Transaction1.aggregate([
...   {
...     $match: {
...       "payment_details.total_amt": { $gt: 500 }
...     }
...   },
...   {
...     $lookup: {
...       from: "Employee",  
...       localField: "name",
...       foreignField: "name",
...       as: "employeeDetails"
...     }
...   },
...   {
...     $unwind: "$employeeDetails"
...   },
...   {
...     $project: {
...       _id: 0,
...       designation: "$employeeDetails.designation"
...     }
...   },
...   {
...     $group: {
...       _id: "$designation"
...     }
...   }
... ]).pretty();
 *************************************************************

10. Find the total quantity of a particular item sold using Map Reduce.

db.Transaction1.mapReduce(
  function() {
    var itemId = this.transaction_details.item_id;
    var quantity = this.transaction_details.quantity;
    emit(itemId, quantity);
  },
  function(key, values) {
    return Array.sum(values);
  },
  {
    query: { "transaction_details.item_id": 102 },
    out: { inline: 1 }
  }
);
 *************************************************************




