ASSIGNMENT 4

1. Create a library database , as given below.

There are individual books, readers, and authors that are present in the
library data model.. A minimal set of labels are as follows:
Book: This label includes all the books
Person: This label includes authors, translators, reviewers,
Readers, Suppliers and so on
Publisher : This label includes the publishers of books in the database



A set of basic relationships are as follows:
PublishedBy : This relationship is used to specify that a book was Published by a
publisher
Votes : This relationship describes the relation between a user and a book, for
example, how a book was rated by a user.
ReviewedBy : This relationship is used to specify that a book was Reviewed and
remarked by a user.
TranslatedBy : This relationship is used to specify that a book was translated to a
language by a user.
IssuedBy : This relationship is used to specify that a book was issued by a user.
ReturnedBy : This relationship is used to specify that a book was Returned by a
user
Every book has the following properties:
Title : This is the title of the book in string format
Tags : This is an array of string tags useful for searching through the database
based on topic, arguments, geographic regions, languages, and so on
Status : the book status , specifying whether its issued or in the library.
Condition : book condition, new or old
Cost : Cost of book
Type : book is a Novel, Journal, suspense thriller etc

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*********************************************************************************************************************
-----------Book Lable-----------------------
CREATE (:Book 
    {title: "The Great Gatsby", 
    tags: ["classic", "novel"], 
    status: "in library", 
    condition: "new", 
    cost: 10.99, 
    type: "Novel"
    });


CREATE (:Book 
	{title: "Tinker,Tailor,Solder,Spy", 
	tags: ["classic", "drama"], 
	status: "in library", 
	condition: "old", 
	cost: 9.99, 
	type: "Novel"
	});


---------------Person Lable--------------------------


CREATE (:Person {name: "John Le Carre",born: "1932-10-19", type: "Author"});
CREATE (:Person {name: "Grahan Greene",born: "1904-10-02",died: "1991-04-02", type: "Author"});
CREATE (:Person {name: "Alan", type: "Reader"});
CREATE (:Person {name: "Lan", type: ["Reader", "Author"]});
CREATE (:Person {name: "Jane Doe", type: "Reviewer"});
CREATE (:Person {name: "Translator X", type: "Translator"});


---------------Publisher Lable-----------

CREATE (:Publisher {name: "Sc"});
CREATE (:Publisher {name: "J.B."});


---------------Publishedby Lable--------------------------

MATCH (b:Book {title: "The Great Gatsby"})
MATCH (p:Publisher {name: "Sc"})
CREATE (b)-[:PUBLISHED_BY]->(p);

MATCH (b:Book {title: "To Kill a Mockingbird"})
MATCH (p:Publisher {name: "J.B."})
CREATE (b)-[:PUBLISHED_BY]->(p);


---------------votes Lable--------------------------

MATCH (b:Book {title: "The Great Gatsby"})
MATCH (r:Person {name: "Alan", type: "Reader"}) 
CREATE (r)-[:VOTES {rating: 5}]->(b);


---------------ReviewedBy Lable--------------------------

MATCH (b:Book {title: "The Great Gatsby"})
MATCH (r:Person {name: "Jane Doe", type: "Reviewer"})
CREATE (r)-[:REVIEWED_BY {remark: "Excellent novel with timeless themes."}]->(b);

---------------TranslatedBy Lable--------------------------

MATCH (book2:Book {title: "Tinker, Tailor, Soldier, Spy"})
MATCH (translatorX:Person {name: "Translator X"})
CREATE (book2)-[:TRANSLATED_BY]->(translatorX)

---------------IssuedBy Lable--------------------------

MATCH (b:Book {title: "The Great Gatsby"})
MATCH (r:Person {name: "Alan", type: "Reader"})
CREATE (r)-[:ISSUED_BY {date: "2024-09-10"}]->(b);


---------------ReturnedBy Lable--------------------------

MATCH (book1:Book {title: "The Great Gatsby"})
MATCH (alan:Person {name: "Alan"})
CREATE (book1)-[:RETURNED_BY]->(alan)


MATCH (book1:Book {title: "The Great Gatsby"})
MATCH (lan:Person {name: "Lan"})
CREATE (book1)-[:RETURNED_BY]->(lan)

MATCH (book1:Book {title: "The Great Gatsby"})
MATCH (john:Person {name: "John Le Carre"})
CREATE (book1)-[:RETURNED_BY]->(john)






////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
2. Consider a Song database, with labels as Artists, Song,
Recording_company, Recoding_studio, song author etc.
Relationships can be as follows
Artist → [Performs] → Song →[Written by] → Song_author.
Song → [Recorded in ] → Recording Studio →[managed by] →Recording
Company
Recording Company → [Finances] → Song
You may add more labels and relationships and their properties, as per assumptions.


// Create Artists
CREATE (:Artist {name: 'Artist A', genre: 'Pop', nationality: 'USA', debutYear: 2010});
CREATE (:Artist {name: 'Artist B', genre: 'Rock', nationality: 'UK', debutYear: 2015});

// Create Songs
CREATE (:Song {title: 'Hit Song A', releaseYear: 2020, duration: '3:45', genre: 'Pop', lyrics: '...'});
CREATE (:Song {title: 'Rock Anthem', releaseYear: 2021, duration: '4:20', genre: 'Rock', lyrics: '...'});

// Create Song Authors
CREATE (:SongAuthor {name: 'Author A', nationality: 'USA', birthYear: 1980});
CREATE (:SongAuthor {name: 'Author B', nationality: 'UK', birthYear: 1990});

// Create Recording Studios
CREATE (:RecordingStudio {name: 'Studio 1', location: 'NYC', capacity: 20, equipment: 'Pro Tools'});
CREATE (:RecordingStudio {name: 'Studio 2', location: 'LA', capacity: 30, equipment: 'Logic Pro'});

// Create Recording Companies
CREATE (:RecordingCompany {name: 'Label A', foundedYear: 2000, headquarters: 'NYC', totalArtistsSigned: 50});

// Create Albums
CREATE (:Album {title: 'Album A', releaseYear: 2020, numberOfTracks: 10, genre: 'Pop'});
CREATE (:Album {title: 'Album B', releaseYear: 2021, numberOfTracks: 12, genre: 'Rock'});

// Create Producers
CREATE (:Producer {name: 'Producer A', experience: 15, notableWorks: 'Work A, Work B'});
CREATE (:Producer {name: 'Producer B', experience: 10, notableWorks: 'Work C, Work D'});

// Artist performs Songs
MATCH (a:Artist {name: 'Artist A'})
MATCH (s:Song {title: 'Hit Song A'})
CREATE (a)-[:PERFORMS]->(s);

MATCH (a:Artist {name: 'Artist B'})
MATCH (s:Song {title: 'Rock Anthem'})
CREATE (a)-[:PERFORMS]->(s);

// Song written by Song Author
MATCH (s:Song {title: 'Hit Song A'})
MATCH (a:SongAuthor {name: 'Author A'})
CREATE (s)-[:WRITTEN_BY]->(a);

MATCH (s:Song {title: 'Rock Anthem'})
MATCH (a:SongAuthor {name: 'Author B'})
CREATE (s)-[:WRITTEN_BY]->(a);

// Song recorded in Recording Studio
MATCH (s:Song {title: 'Hit Song A'})
MATCH (rs:RecordingStudio {name: 'Studio 1'})
CREATE (s)-[:RECORDED_IN]->(rs);

MATCH (s:Song {title: 'Rock Anthem'})
MATCH (rs:RecordingStudio {name: 'Studio 2'})
CREATE (s)-[:RECORDED_IN]->(rs);

// Recording Studio managed by Recording Company
MATCH (rs:RecordingStudio {name: 'Studio 1'})
MATCH (rc:RecordingCompany {name: 'Label A'})
CREATE (rs)-[:MANAGED_BY]->(rc);

// Recording Company finances Song
MATCH (rc:RecordingCompany {name: 'Label A'})
MATCH (s:Song {title: 'Hit Song A'})
CREATE (rc)-[:FINANCES]->(s);

// Album contains Songs
MATCH (a:Album {title: 'Album A'})
MATCH (s:Song {title: 'Hit Song A'})
CREATE (a)-[:CONTAINS]->(s);

MATCH (a:Album {title: 'Album B'})
MATCH (s:Song {title: 'Rock Anthem'})
CREATE (a)-[:CONTAINS]->(s);

// Producer produces Songs
MATCH (p:Producer {name: 'Producer A'})
MATCH (s:Song {title: 'Hit Song A'})
CREATE (p)-[:PRODUCES]->(s);

MATCH (p:Producer {name: 'Producer B'})
MATCH (s:Song {title: 'Rock Anthem'})
CREATE (p)-[:PRODUCES]->(s);


////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
3. Consider an Employee database, with a minimal set of labels as follows
Employee : denotes a person as an employee of the organization
Department : denotes the different departments, in which employees work.
Skillset : A list of skills acquired by an employee
Projects : A list of projects in which an employee works.
A minimal set of relationships can be as follows:
Works_in : employee works in a department
Has_acquired : employee has acquired a skill
Assigned_to : employee assigned to a project
Controlled_by : A project is controlled by a department
Project_manager : Employee is a project_manager of a Project
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

MATCH ()-[r]->() DELETE r; 


### 1. Create Employees
```cypher
CREATE (e1:Employee {name: 'Alice Smith', age: 30, position: 'Software Engineer'});
CREATE (e2:Employee {name: 'Bob Johnson', age: 45, position: 'Project Manager'});
CREATE (e3:Employee {name: 'Charlie Brown', age: 28, position: 'Data Analyst'});
```


### 2. Create Departments
```cypher
CREATE (d1:Department {name: 'Engineering'});
CREATE (d2:Department {name: 'Data Science'});
CREATE (d3:Department {name: 'Project Management'});
```

### 3. Create Skillsets
```cypher
CREATE (s1:Skillset {name: 'Java'});
CREATE (s2:Skillset {name: 'Python'});
CREATE (s3:Skillset {name: 'Data Analysis'});
```


### 4. Create Projects
```cypher
CREATE (p1:Projects {name: 'Project Alpha', deadline: '2024-12-31'});
CREATE (p2:Projects {name: 'Project Beta', deadline: '2025-06-30'});
```



### 5. Create Relationships

#### 5.1 Employee Works In Department

MATCH (e1:Employee {name: 'Alice Smith'})
MATCH (d1:Department {name: 'Engineering'})
CREATE (e1)-[:WORKS_IN]->(d1) return e1,d1;

MATCH (e2:Employee {name: 'Bob Johnson'})
MATCH (d3:Department {name: 'Project Management'})
CREATE (e2)-[:WORKS_IN]->(d3) return e2,d3;


MATCH (e3:Employee {name: 'Charlie Brown'})
MATCH (d2:Department {name: 'Data Science'})
CREATE (e3)-[:WORKS_IN]->(d2) return e3,d2;


#### 5.2 Employee Has Acquired Skillset


MATCH (e1:Employee {name: 'Alice Smith'})
MATCH (s1:Skillset {name: 'Java'})
CREATE (e1)-[:HAS_ACQUIRED]->(s1) return e1,s1;

MATCH (e1:Employee {name: 'Alice Smith'})
MATCH (s2:Skillset {name: 'Python'})
CREATE (e1)-[:HAS_ACQUIRED]->(s2) return e1,s2;



MATCH (e2:Employee {name: 'Bob Johnson'})
MATCH (s2:Skillset {name: 'Python'})
CREATE (e2)-[:HAS_ACQUIRED]->(s2) return e2,s2;



MATCH (e3:Employee {name: 'Charlie Brown'})
MATCH (s3:Skillset {name: 'Data Analysis'})
CREATE (e3)-[:HAS_ACQUIRED]->(s3) return e3,s3;

#### 5.3 Employee Assigned To Project

MATCH (e1:Employee {name: 'Alice Smith'})
MATCH (p1:Projects {name: 'Project Alpha'})
CREATE (e1)-[:ASSIGNED_TO]->(p1) return e1,p1;



MATCH (e2:Employee {name: 'Bob Johnson'})
MATCH (p2:Projects {name: 'Project Beta'})
CREATE (e2)-[:ASSIGNED_TO]->(p2) return e2,p2;


MATCH (e3:Employee {name: 'Charlie Brown'})
MATCH (p1:Projects {name: 'Project Alpha'})
CREATE (e3)-[:ASSIGNED_TO]->(p1) return e3,p1;


#### 5.4 Project Controlled By Department

MATCH (p1:Projects {name: 'Project Alpha'})
MATCH (d1:Department {name: 'Engineering'})
CREATE (p1)-[:CONTROLLED_BY]->(d1) return p1,d1;

MATCH (p2:Projects {name: 'Project Beta'})
MATCH (d3:Department {name: 'Project Management'})
CREATE (p2)-[:CONTROLLED_BY]->(d3) return p2,d3;


#### 5.5 Employee Is Project Manager

MATCH (e2:Employee {name: 'Bob Johnson'})
MATCH (p2:Projects {name: 'Project Beta'})
CREATE (e2)-[:PROJECT_MANAGER]->(p2) return e2,p2;

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

4. Consider a movie database, with nodes as Actors, Movies, Roles, Producer,
Financier, Director. Assume appropriate relationships between
the nodes, include properties for nodes and relationships.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Create Actors
CREATE (:Actor {name: 'Actor A', birthYear: 1985, nationality: 'USA', gender: 'Male'});
CREATE (:Actor {name: 'Actor B', birthYear: 1990, nationality: 'UK', gender: 'Female'});

// Create Movies
CREATE (:Movie {title: 'Movie A', releaseYear: 2020, duration: '120 min', genre: 'Action', rating: 8.5});
CREATE (:Movie {title: 'Movie B', releaseYear: 2021, duration: '90 min', genre: 'Comedy', rating: 7.0});

// Create Roles
CREATE (:Role {characterName: 'Hero', screenTime: '60 min'});
CREATE (:Role {characterName: 'Villain', screenTime: '30 min'});

// Create Producers
CREATE (:Producer {name: 'Producer A', company: 'Production Co', experienceYears: 10});
CREATE (:Producer {name: 'Producer B', company: 'Filmworks', experienceYears: 5});

// Create Financiers
CREATE (:Financier {name: 'Financier A', type: 'Company', investmentAmount: 1000000});
CREATE (:Financier {name: 'Financier B', type: 'Individual', investmentAmount: 500000});

// Create Directors
CREATE (:Director {name: 'Director A', experienceYears: 15, nationality: 'USA'});
CREATE (:Director {name: 'Director B', experienceYears: 8, nationality: 'Canada'});


// Actor plays Role
MATCH (a:Actor {name: 'Actor A'})
MATCH (r:Role {characterName: 'Hero'})
CREATE (a)-[:PLAYS]->(r);

MATCH (a:Actor {name: 'Actor B'})
MATCH (r:Role {characterName: 'Villain'})
CREATE (a)-[:PLAYS]->(r);

// Role in Movie
MATCH (r:Role {characterName: 'Hero'})
MATCH (m:Movie {title: 'Movie A'})
CREATE (r)-[:IN]->(m);

MATCH (r:Role {characterName: 'Villain'})
MATCH (m:Movie {title: 'Movie A'})
CREATE (r)-[:IN]->(m);

// Movie directed by Director
MATCH (m:Movie {title: 'Movie A'})
MATCH (d:Director {name: 'Director A'})
CREATE (m)-[:DIRECTED_BY]->(d);

MATCH (m:Movie {title: 'Movie B'})
MATCH (d:Director {name: 'Director B'})
CREATE (m)-[:DIRECTED_BY]->(d);

// Movie produced by Producer
MATCH (m:Movie {title: 'Movie A'})
MATCH (p:Producer {name: 'Producer A'})
CREATE (m)-[:PRODUCED_BY]->(p);

MATCH (m:Movie {title: 'Movie B'})
MATCH (p:Producer {name: 'Producer B'})
CREATE (m)-[:PRODUCED_BY]->(p);

// Movie financed by Financier
MATCH (m:Movie {title: 'Movie A'})
MATCH (f:Financier {name: 'Financier A'})
CREATE (m)-[:FINANCED_BY]->(f);

MATCH (m:Movie {title: 'Movie B'})
MATCH (f:Financier {name: 'Financier B'})
CREATE (m)-[:FINANCED_BY]->(f);


////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
5. Create a Social network database , with labels as Person, Affiliations,
Groups, Story, Timeline etc. Some of the relationships can be as follows:
Person →[friend of]→ Person→[affiliated to]→affiliations
Person →[belongs to]→ Groups, Person →[create]→Story→[refers to]→Person
Person→[creates]→Timeline→[reference for]→ Story ,
Timeline→[contains]→Messages
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Create Persons
CREATE (:Person {name: 'Alice', age: 30, location: 'NYC', gender: 'Female'});
CREATE (:Person {name: 'Bob', age: 25, location: 'LA', gender: 'Male'});
CREATE (:Person {name: 'Charlie', age: 35, location: 'Chicago', gender: 'Non-binary'});

// Create Affiliations
CREATE (:Affiliations {type: 'Employment', organization: 'Company A', startYear: 2020});
CREATE (:Affiliations {type: 'Volunteer', organization: 'Non-Profit B', startYear: 2018});

// Create Groups
CREATE (:Groups {name: 'Book Club', description: 'A club for book lovers', creationDate: '2021-01-01'});
CREATE (:Groups {name: 'Running Group', description: 'For fitness enthusiasts', creationDate: '2020-05-15'});

// Create Stories
CREATE (:Story {title: 'My First Adventure', content: 'Content of the adventure...', creationDate: '2023-07-01'});
CREATE (:Story {title: 'A Day at the Beach', content: 'Content about the beach...', creationDate: '2023-07-10'});

// Create Timelines
CREATE (:Timeline {startDate: '2023-01-01', endDate: '2023-12-31', description: 'Yearly Overview'});

// Create Messages
CREATE (:Messages {content: 'Hello, how are you?', timestamp: '2023-07-15T10:00:00', sender: 'Alice'});
CREATE (:Messages {content: 'Looking forward to our next meeting!', timestamp: '2023-07-16T11:00:00', sender: 'Bob'});


// Person friendships
MATCH (a:Person {name: 'Alice'})
MATCH (b:Person {name: 'Bob'})
CREATE (a)-[:FRIEND_OF]->(b);

MATCH (b:Person {name: 'Bob'})
MATCH (c:Person {name: 'Charlie'})
CREATE (b)-[:FRIEND_OF]->(c);

// Person affiliations
MATCH (a:Person {name: 'Alice'})
MATCH (aff:Affiliations {organization: 'Company A'})
CREATE (a)-[:AFFILIATED_TO]->(aff);

// Person group memberships
MATCH (a:Person {name: 'Alice'})
MATCH (g:Groups {name: 'Book Club'})
CREATE (a)-[:BELONGS_TO]->(g);

MATCH (b:Person {name: 'Bob'})
MATCH (g:Groups {name: 'Running Group'})
CREATE (b)-[:BELONGS_TO]->(g);

// Person creates stories
MATCH (a:Person {name: 'Alice'})
MATCH (s:Story {title: 'My First Adventure'})
CREATE (a)-[:CREATES]->(s);

MATCH (b:Person {name: 'Bob'})
MATCH (s:Story {title: 'A Day at the Beach'})
CREATE (b)-[:CREATES]->(s);

// Story refers to persons
MATCH (s:Story {title: 'My First Adventure'})
MATCH (b:Person {name: 'Bob'})
CREATE (s)-[:REFERS_TO]->(b);

// Person creates timeline
MATCH (a:Person {name: 'Alice'})
MATCH (t:Timeline {description: 'Yearly Overview'})
CREATE (a)-[:CREATES]->(t);

// Timeline references story
MATCH (t:Timeline {description: 'Yearly Overview'})
MATCH (s:Story {title: 'My First Adventure'})
CREATE (t)-[:REFERENCE_FOR]->(s);

// Timeline contains messages
MATCH (t:Timeline {description: 'Yearly Overview'})
MATCH (msg:Messages {content: 'Hello, how are you?'})
CREATE (t)-[:CONTAINS]->(msg);

MATCH (t:Timeline {description: 'Yearly Overview'})
MATCH (msg:Messages {content: 'Looking forward to our next meeting!'})
CREATE (t)-[:CONTAINS]->(msg);


////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
