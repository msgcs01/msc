ASSIGNMENT 1

> db.Film.insert({
"Film Id":1,
"Title of the film":"RRR",
"Year of release":2021,
"Genre":["Action","Funny"],
"Actors":[{"Fnm":"A1","Lnm":"L1"},
{"Fnm":"A2","Lnm":"L2"}],
"Director":[{"Fnm":"D1","Lnm":"L3"}],
"Release Details":[{"Place":"Pune"},
{"date":"20/05/2023"},
{"ratings":"5"}]
})
########################################################################################

>db.Film.find({ "Release Details.place": "Pune" })
########################################################################################
> db.Film.find().pretty()
########################################################################################
db.Film.insertMany([
{
"Film Id":6,
"Title of the film":"EEE",
"Year of release":2021,
"Genre":["Action","Funny"],
"Actors":[{"Fnm":"A1","Lnm":"L1"},
{"Fnm":"A2","Lnm":"L2"}],
"Director":[{"Fnm":"D1","Lnm":"L3"}],
"Release Details":[{"Place":"Pune"},
{"date":"20/05/2023"},
{"ratings":"5"}]
}
])

#####################################################################################
4. Add a value to the rating of the film whose title starts with ‘T’.

> db.Film.updateOne(   { "Title of the film":{$regex:"^T"}},
   { $set: { "release_details.rating": 100 } } )

#############################################
5. Add an actor named "______John_______" in the ‘Actor’ collection.
Also add the details of the film in ‘Film’ collection in which this actor
has acted in.

db.Actor.insertOne({
...   "actor_id": "A004",
...   "first_name": "John",
...   "last_name": "Doe",
...   "address": {
...     "street": "789 Maple Street",
...     "city": "Metropolis",
...     "state": "NY",
...     "country": "USA",
...     "pin_code": "10001"
...   },
...   "contact_details": {
...     "email": "john.doe@example.com",
...     "phone_no": "+1-555-9876"
...   },
...   "age": 30
... })
#############################################
6. Delete the film "______________".

db.Film.deleteOne({ "title": "Jungle Adventure" })
{ "acknowledged" : true, "deletedCount" : 1 }
#############################################
7. Delete an actor named "_________".

 db.Actor.deleteOne({ "first_name": "Jane", "last_name": "Smith" })
{ "acknowledged" : true, "deletedCount" : 1 }

#############################################

8. Delete all actors from an ‘Actor’ collection who have age greater than
“_____”

db.Actor.deleteMany({ "age": { $gt: 40 } })
{ "acknowledged" : true, "deletedCount" : 1 }
> 
#############################################
9. Update the actor’s address where Actor Id is “ ______”.

db.Actor.updateOne(
...   { "actor_id": "A004" },
...   { $set: { 
...       "address.street": "101 Pine Road",
...       "address.city": "Gotham",
...       "address.state": "NJ",
...       "address.country": "USA",
...       "address.pin_code": "07001"
...     } 
...   }
... )
{ "acknowledged" : true, "matchedCount" : 1, "modifiedCount" : 1 }
> 
#############################################

10. Update the genre of the film directed by “___________”.


db.Film.updateOne(
...   { "directors.first_name": "DD4", "directors.last_name": "LL4" },
...   { $set: { "genres": ["Action", "Adventure"] } }
... )
{ "acknowledged" : true, "matchedCount" : 1, "modifiedCount" : 1 }
> 
